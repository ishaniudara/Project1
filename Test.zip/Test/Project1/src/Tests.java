import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Tests {
	
	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\user\\Downloads\\chromedriver_win32 (2)\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://demoqa.com/books");
		driver.manage().window().maximize();		
		//register new user
		
//		driver.findElement(By.id("firstname")).sendKeys("Ishani");
//		driver.findElement(By.id("lastname")).sendKeys("udara");
//		driver.findElement(By.id("userName")).sendKeys("Ishani");
//		driver.findElement(By.id("password")).sendKeys("Ishani@1234");
//		driver.findElement(By.cssSelector("div.recaptcha-checkbox-checkmark")).click();
//		driver.findElement(By.id("register")).click();
		
		System.out.println(driver.getTitle());
		
		//login user
		driver.findElement(By.xpath("//button[text()='Login']")).click();
		driver.findElement(By.id("userName")).sendKeys("Ishani");
		driver.findElement(By.id("password")).sendKeys("Ishani@1234");
		driver.findElement(By.xpath("//button[text()='Login']")).click();
		Thread.sleep(3000);
		
		//search book
		driver.findElement(By.id("searchBox")).sendKeys("Gi");
		Thread.sleep(3000);
		
		
		
	//Logout user
		driver.findElement(By.xpath("//button[text()='Log out']")).click();
		
		
		
		driver.close();

	}

}
